#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

REPO_ROOT = Path(__file__).resolve().parents[2]
SRC = REPO_ROOT / 'src'
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from page_text import collect_text, to_bullets
from page_images import collect_images
from image_selection import select_best_images


def load_json(p: Path) -> Any:
    try:
        return json.loads(p.read_text(encoding='utf-8'))
    except UnicodeDecodeError:
        return json.loads(p.read_text(encoding='utf-8-sig', errors='replace'))


def save_json(p: Path, obj: Any) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding='utf-8')


def find_existing_pages_source(hint: Path) -> Optional[Path]:
    candidates = [
        hint,
        REPO_ROOT / 'process' / 'onenote' / 'manifest.json',
        REPO_ROOT / 'process' / 'onenote' / 'pages_index.json',
    ]
    base = REPO_ROOT / 'process' / 'onenote'
    if base.exists():
        for cand in base.rglob('manifest.json'):
            candidates.append(cand)
    for c in candidates:
        try:
            if c and c.exists() and c.is_file():
                return c
        except Exception:
            continue
    return None


def iter_pages_from_pages_index(obj: Any) -> List[Dict[str, Any]]:
    if isinstance(obj, list):
        return [p for p in obj if isinstance(p, dict)]
    if isinstance(obj, dict) and isinstance(obj.get('pages'), list):
        return [p for p in obj['pages'] if isinstance(p, dict)]
    return []


def _safe_page_filename(page_id: str) -> str:
    return (page_id or '').replace('/', '_')


def _find_page_json_file(page_id: str, pages_dir: Path) -> Optional[Path]:
    pid = (page_id or '').strip()
    if not pid:
        return None
    cand = pages_dir / f"{pid}.json"
    if cand.exists():
        return cand
    cand2 = pages_dir / f"{_safe_page_filename(pid)}.json"
    if cand2.exists():
        return cand2
    try:
        for hit in pages_dir.rglob(f"{_safe_page_filename(pid)}.json"):
            if hit.is_file():
                return hit
    except Exception:
        pass
    return None


def iter_pages_from_manifest(obj: Any, pages_dir: Path) -> List[Dict[str, Any]]:
    if not isinstance(obj, dict):
        return []
    page_ids = obj.get('processed_pages')
    if not isinstance(page_ids, list) or not page_ids:
        return []
    pages: List[Dict[str, Any]] = []
    seen = set()
    for pid in page_ids:
        if not isinstance(pid, str):
            continue
        pid = pid.strip()
        if not pid or pid in seen:
            continue
        seen.add(pid)
        pfile = _find_page_json_file(pid, pages_dir)
        if pfile and pfile.exists():
            try:
                pages.append(load_json(pfile))
            except Exception:
                pages.append({'metadata': {'page_id': pid}, 'title': pid, 'blocks': [], 'assets': {}})
        else:
            pages.append({'metadata': {'page_id': pid}, 'title': pid, 'blocks': [], 'assets': {}})
    return pages


def _page_id(page: Dict[str, Any]) -> str:
    m = page.get('metadata')
    if isinstance(m, dict) and isinstance(m.get('page_id'), str):
        return m['page_id']
    pid = page.get('page_id')
    return pid if isinstance(pid, str) else ''


def _page_section(page: Dict[str, Any]) -> str:
    m = page.get('metadata')
    if isinstance(m, dict) and isinstance(m.get('section'), str):
        return m['section']
    sec = page.get('section')
    return sec if isinstance(sec, str) else ''


def _page_section_group(page: Dict[str, Any]) -> str:
    m = page.get('metadata')
    if isinstance(m, dict) and isinstance(m.get('section_group'), str):
        return m['section_group']
    return ''


def _page_section_path(page: Dict[str, Any]) -> str:
    m = page.get('metadata')
    if isinstance(m, dict) and isinstance(m.get('section_path'), str):
        return m['section_path']
    return ''


def _ensure_full_pages(pages: List[Dict[str, Any]], pages_dir: Path) -> List[Dict[str, Any]]:
    """pages_index.json often contains lightweight entries (no blocks/assets).

    To build bullets (including audio transcripts) and select images, we need the
    full per-page JSON produced by process_onenote. This function upgrades each
    page entry by loading its pages/<page_id>.json file when available.
    """
    out: List[Dict[str, Any]] = []
    for pg in pages:
        if not isinstance(pg, dict):
            continue
        pid = (_page_id(pg) or '').strip()
        # If blocks already present, keep as-is
        if isinstance(pg.get('blocks'), list) and pg.get('blocks'):
            out.append(pg)
            continue
        # Try to load full page json
        pfile = _find_page_json_file(pid, pages_dir) if pid else None
        if pfile and pfile.exists():
            try:
                full = load_json(pfile)
                # keep some fields from lightweight entry if missing in full
                if isinstance(full, dict):
                    out.append(full)
                    continue
            except Exception:
                pass
        out.append(pg)
    return out


def _audio_fallback_text(page: Dict[str, Any]) -> str:
    blocks = page.get('blocks')
    if not isinstance(blocks, list):
        return ''
    parts: List[str] = []
    for b in blocks:
        if not isinstance(b, dict):
            continue
        if (b.get('type') or '').lower() != 'audio':
            continue
        tr = b.get('transcript')
        if isinstance(tr, str) and tr.strip():
            parts.append(f"Note vocale : {tr.strip()}")
            continue
        meta = b.get('transcript_meta')
        if isinstance(meta, dict):
            status = (meta.get('status') or '').strip().lower()
            err = (meta.get('error') or '').strip()
            if status and status != 'ok':
                msg = f"Note vocale : transcription {status}"
                if err:
                    msg += f" ({err})"
                parts.append(msg)
                continue
        parts.append('Note vocale : (enregistrement présent, transcription absente)')
    return "\n".join(parts).strip()


def build(pages_source: Path, out_json: Path, *, case_id: str, section_name: str, max_images: int, max_bullets: int) -> None:
    if not pages_source.exists():
        found = find_existing_pages_source(pages_source)
        if not found:
            raise FileNotFoundError(f"pages source not found: {pages_source}")
        pages_source = found

    obj = load_json(pages_source)
    pages = iter_pages_from_pages_index(obj)

    pages_dir = pages_source.parent / 'pages'
    if not pages_dir.exists():
        pages_dir = REPO_ROOT / 'process' / 'onenote' / 'pages'

    if not pages:
        pages = iter_pages_from_manifest(obj, pages_dir)
    else:
        # Critical fix: pages_index.json entries may not contain blocks/assets
        pages = _ensure_full_pages(pages, pages_dir)

    if not pages:
        raise SystemExit('No pages found (need pages_index.json with pages, or manifest.json with processed_pages + per-page JSON files).')

    section_norm = section_name
    filtered: List[Dict[str, Any]] = []
    seen_pid = set()
    for pg in pages:
        pid = (_page_id(pg) or '').strip()
        if pid and pid in seen_pid:
            continue
        sec_norm = _page_section(pg)
        grp_norm = _page_section_group(pg)
        path_norm = _page_section_path(pg)
        if section_norm:
            if grp_norm:
                if grp_norm != section_norm:
                    continue
            else:
                if sec_norm and sec_norm != section_norm:
                    continue
            if path_norm and path_norm == section_norm:
                pass
        if pid:
            seen_pid.add(pid)
        filtered.append(pg)
    pages = filtered

    slides: List[Dict[str, Any]] = []
    slides.append({'type': 'PART_DIVIDER', 'part': 1, 'title': 'Etat des lieux (Pages OneNote)'})

    for pg in pages:
        title = (pg.get('title') or 'Page').strip()

        text = collect_text(pg)
        if not (text or "").strip():
            text = _audio_fallback_text(pg)

        # Source complète, non tronquée, utilisée ensuite par humanize_page_cards.py.
        # Ce champ doit rester le plus proche possible des notes/transcriptions d'origine.
        source_text = (text or "").strip()

        # Version courte utilisée pour compatibilité et premier affichage.
        bul = to_bullets(source_text, max_lines=max_bullets)

        imgs = collect_images(pg)
        imgs = select_best_images(pg, imgs, title=title, bullets=bul, max_images=max_images)

        if not (bul or '').strip() and not imgs:
            continue

        slides.append({
            'type': 'CONTENT_TEXT_IMAGES' if imgs else 'CONTENT_TEXT',
            'part': 1,
            'title': title,
            'bullets': bul,
            'images': imgs,
            'page_id': _page_id(pg),

            # Source complète, avant troncature et avant humanisation.
            # C'est ce champ que l'on utilisera prioritairement ensuite.
            "raw_text": source_text,
        })

    out = {
        'case_id': case_id,
        'report_type': 'PAGE_CARDS_PART1',
        'section_context': {'onenote_section_name': section_norm},
        'macro_parts': [{'macro_part': 1, 'macro_part_name': 'Etat des lieux (Pages OneNote)'}],
        'slides': slides,
    }
    save_json(out_json, out)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument('--pages-index', required=True)
    ap.add_argument('--out', default='process/page_cards/assembled_page_cards.json')
    ap.add_argument('--case-id', required=True)
    ap.add_argument('--section-name')
    ap.add_argument('--max-images', type=int, default=6)
    ap.add_argument('--max-bullets', type=int, default=10)
    args = ap.parse_args()
    build(Path(args.pages_index), Path(args.out), case_id=args.case_id, section_name=args.section_name, max_images=args.max_images, max_bullets=args.max_bullets)
    print('Wrote:', args.out)


if __name__ == '__main__':
    main()
